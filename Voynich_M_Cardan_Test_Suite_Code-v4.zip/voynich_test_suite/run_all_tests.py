import os, sys, time

# Add current dir to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def run_all():
    print("=" * 70)
    print("SUITE DE TESTES E AUDITORIA - AUTOMATO ESTOCASTICO M_CARDAN")
    print("Autor: Marcelo Aparecido Ferreira Junior")
    print("DOI Zenodo: 10.5281/zenodo.23287068")
    print("=" * 70)
    
    t0 = time.time()
    
    # Run plots generator first
    try:
        from tests import generate_diagnostic_plots
        generate_diagnostic_plots.run_all_plots()
    except Exception as e:
        print(f"Aviso na geração de gráficos: {e}")

    from tests import (
        test_t70_sparsity,
        test_t72_loq_20_quires,
        test_t73_svd_resilience,
        test_t74_currier_ab,
        test_t75a_f1v_decomposer,
        test_t75d_out_of_sample,
        test_t76_astronomical_out_of_sample,
        test_g4_mdl_compression,
        test_botanical_cooccurrence
    )

    tests = [
        ("T70 (Esparsidade Inter-Token)", test_t70_sparsity.run_t70_test),
        ("T72 / LOQ (20 Quires)", test_t72_loq_20_quires.run_t72_test),
        ("T73 (Resiliência SVD)", test_t73_svd_resilience.run_t73_test),
        ("T74 (Currier A vs B)", test_t74_currier_ab.run_t74_test),
        ("T75-A (Parser f1v)", test_t75a_f1v_decomposer.run_t75a_test),
        ("T75-D (Out-of-Sample Botânica)", test_t75d_out_of_sample.run_t75d_out_of_sample_test),
        ("T76-D (Out-of-Sample Astronomia C3)", test_t76_astronomical_out_of_sample.run_t76_astronomical_out_of_sample_test),
        ("Portão G4 (Score MDL)", test_g4_mdl_compression.run_g4_mdl_test),
        ("Botânica Quimérica", test_botanical_cooccurrence.run_botanical_test)
    ]

    passed = 0
    failed = 0

    for name, func in tests:
        try:
            res = func()
            if res:
                passed += 1
            else:
                failed += 1
        except Exception as e:
            print(f"ERRO NO TESTE {name}: {e}")
            failed += 1

    t1 = time.time()
    print("=" * 70)
    print("RESUMO DA EXECUÇÃO DA SUITE:")
    print(f"Total de Testes Executados: {len(tests)}")
    print(f"Aprovados [PASSED]: {passed}")
    print(f"Reprovados [FAILED]: {failed}")
    print(f"Tempo Total: {t1 - t0:.3f} segundos")
    print("=" * 70)

if __name__ == "__main__":
    run_all()
