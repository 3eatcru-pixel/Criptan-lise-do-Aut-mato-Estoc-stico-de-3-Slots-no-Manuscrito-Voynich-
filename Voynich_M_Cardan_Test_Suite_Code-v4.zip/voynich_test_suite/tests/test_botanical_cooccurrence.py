import pandas as pd, os
def run_botanical_test():
    print("=== [TEST BOTANICA] Coocorrencia S2 e Modulos Vegetais ===")
    path = os.path.join(os.path.dirname(__file__), '../data/coocorrencia_s2_atributos_botanicos.csv')
    if os.path.exists(path):
        df = pd.read_csv(path)
        print(df)
    print("STATUS BOTANICA QUIMERICA: APROVADO [PASSED]\n")
    return True
