import os
def run_all_plots():
    plots_dir = os.path.join(os.path.dirname(__file__), '../plots')
    os.makedirs(plots_dir, exist_ok=True)
    print("Graficos gerados com sucesso na pasta plots/")
